-- SQL statements for table creation
-- Department table
CREATE TABLE Department (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
    -- Add other fields as needed
);

-- Create other tables similarly...