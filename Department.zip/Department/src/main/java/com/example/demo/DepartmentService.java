package com.example.demo;

import com.example.demo.DepartmentModel;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.google.common.base.Optional;

@Service
public class DepartmentService {
	@Autowired
    private DepartmentRepository departmentRepository;

    public List<DepartmentModel> getAllDepartments() {
        return departmentRepository.findAll();
    }

    public java.util.Optional<DepartmentModel> getDepartmentById(Long id) {
        return departmentRepository.findById(id);
    }

    public DepartmentModel createDepartment(DepartmentModel department) {
        return departmentRepository.save(department);
    }

    public DepartmentModel updateDepartment(Long id, DepartmentModel department) {
        if (departmentRepository.existsById(id)) {
            department.setId(id);
            return departmentRepository.save(department);
        } else {
            return null; // Or throw an exception
        }
    }

    public void deleteDepartment(Long id) {
        departmentRepository.deleteById(id);
    }
}


