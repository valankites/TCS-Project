package com.example.demo;

import com.example.demo.DepartmentModel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@SuppressWarnings("unused")
@Repository
public interface DepartmentRepository extends JpaRepository<DepartmentModel, Long> {

}
