package com.example.demo;


import com.example.demo.DepartmentService;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@SuppressWarnings("unused")
@RestController
@RequestMapping("/departments")
public class DepartmentController {
	
	 @Autowired
	    private DepartmentService departmentService;

	    @GetMapping
	    public ResponseEntity<List<DepartmentModel>> getAllDepartments() {
	        List<DepartmentModel> departments = departmentService.getAllDepartments();
	        return ResponseEntity.ok().body(departments);
	    }

	    @GetMapping("/{id}")
	    public ResponseEntity<DepartmentModel> getDepartmentById(@PathVariable("id") Long id) {
	        Optional<DepartmentModel> department = departmentService.getDepartmentById(id);
	        return department.map(value -> ResponseEntity.ok().body(value))
	                .orElseGet(() -> ResponseEntity.notFound().build());
	    }

	    @PostMapping
	    public ResponseEntity<DepartmentModel> createDepartment(@RequestBody DepartmentModel department) {
	    	DepartmentModel createdDepartment = departmentService.createDepartment(department);
	        return ResponseEntity.status(HttpStatus.CREATED).body(createdDepartment);
	    }

	    @PutMapping("/{id}")
	    public ResponseEntity<DepartmentModel> updateDepartment(@PathVariable("id") Long id, @RequestBody DepartmentModel department) {
	    	DepartmentModel updatedDepartment = departmentService.updateDepartment(id, department);
	        return updatedDepartment != null ? ResponseEntity.ok().body(updatedDepartment) : ResponseEntity.notFound().build();
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteDepartment(@PathVariable("id") Long id) {
	        departmentService.deleteDepartment(id);
	        return ResponseEntity.noContent().build();
	    }

}
