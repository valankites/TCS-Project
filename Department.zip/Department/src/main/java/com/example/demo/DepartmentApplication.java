package com.example.demo;

import com.example.demo.DepartmentModel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class DepartmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DepartmentApplication.class, args);
		
		
		
		DepartmentModel department = new DepartmentModel();
		department.setName("John Doe");
		// Database connection parameters
        String url = "jdbc:h2:~/test"; // JDBC URL for H2 database
        String username = "sa";
        String password = "";
        
      //create table
     // SQL DDL statement to create Department table
        String createTableSql = "CREATE TABLE Department6 ("
                             + "id INT AUTO_INCREMENT PRIMARY KEY,"
                             + "name VARCHAR(255) NOT NULL"
                             + ")";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {

            // Execute the SQL DDL statement to create the Department table
            statement.execute(createTableSql);

            System.out.println("Department table created successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        //end Create table
        
        

        // SQL insert query
        String sql = "INSERT INTO Department6 (name) VALUES (?)";

        try (
            // Establishing database connection
            Connection connection = DriverManager.getConnection(url, username, password);
            // Creating PreparedStatement object for SQL execution
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
        ) {
            // Setting values for the insert query
            preparedStatement.setString(1, "HR");
//            preparedStatement.setString(2, "Admin");
//             preparedStatement.setString(3, "IT");
            
            // Executing the insert query
            int rowsAffected = preparedStatement.executeUpdate();
            
            // Checking if the insert was successful
            if (rowsAffected > 0) {
                System.out.println("Insert successful.");
            } else {
                System.out.println("Insert failed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
		
	}

}
