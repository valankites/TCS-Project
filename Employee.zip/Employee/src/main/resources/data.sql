-- SQL statements for table creation
-- Employee table
CREATE TABLE Employee (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL
    -- Add other fields as needed
);

-- Create other tables similarly...