package com.example.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillsApplication.class, args);
		
		// Database connection parameters
        String url = "jdbc:h2:~/test"; // JDBC URL for H2 database
        String username = "sa";
        String password = "";
        
      //create table
     // SQL DDL statement to create Department table
        String createTableSql = "CREATE TABLE skill1 ("
                             + "id INT AUTO_INCREMENT PRIMARY KEY,"
                             + "name VARCHAR(255) NOT NULL,"
                             + "description VARCHAR(255) NOT NULL"
                             + ")";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {

            // Execute the SQL DDL statement to create the Department table
            statement.execute(createTableSql);

            System.out.println("Department table created successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
        //end Create table
        
        

        // SQL insert query
     // SQL INSERT statement to insert a new skill
        String insertSql = "INSERT INTO skill1 (name, description) VALUES (?, ?)";

        // Skill data to insert
        String skillName = "Java";
        String skillDescription = "Programming language";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(insertSql)) {

            // Set parameters for the prepared statement
            preparedStatement.setString(1, skillName);
            preparedStatement.setString(2, skillDescription);

            // Execute the SQL INSERT statement
            int rowsInserted = preparedStatement.executeUpdate();

            if (rowsInserted > 0) {
                System.out.println("A new skill was inserted successfully.");
            } else {
                System.out.println("Insertion failed.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
	}

}
