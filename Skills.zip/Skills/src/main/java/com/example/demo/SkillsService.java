package com.example.demo;

import java.util.List;
import java.util.Optional;

import com.example.demo.Skill;
import com.example.demo.SkillRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SkillsService {
	
	@Autowired
    private SkillRepository skillRepository;

    public List<Skill> getAllSkills() {
        return skillRepository.findAll();
    }

    public Optional<Skill> getSkillById(Long id) {
        return skillRepository.findById(id);
    }

    public Skill createSkill(Skill skill) {
        return skillRepository.save(skill);
    }

    public Skill updateSkill(Long id, Skill skill) {
        if (skillRepository.existsById(id)) {
            skill.setId(id);
            return skillRepository.save(skill);
        } else {
            return null; // Or throw an exception
        }
    }

    public void deleteSkill(Long id) {
        skillRepository.deleteById(id);
    }

}
